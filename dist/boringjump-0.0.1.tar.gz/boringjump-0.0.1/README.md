## boringjump

boringjump is a basic jumping game made with opencv.

